import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useAuth } from '../../hooks/useAuth';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';

export default function PainelCerimonialista() {
  const router = useRouter();
  const { user, loading, cerimonialista, isCerimonialista, signOut } = useAuth();
  const [leadsCount, setLeadsCount] = useState(0);
  const [modelosCount, setModelosCount] = useState(0);
  const [leadsLoading, setLeadsLoading] = useState(true);
  const [modelosLoading, setModelosLoading] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [loading, user, router]);

  useEffect(() => {
    async function buscarDados() {
      if (!cerimonialista?.id) {
        setLeadsLoading(false);
        setModelosLoading(false);
        return;
      }

      const [leadsRes, modelosRes] = await Promise.all([
        supabase
          .from('cerimonialista_leads')
          .select('*', { count: 'exact', head: true })
          .eq('cerimonialista_id', cerimonialista.id)
          .neq('estagio', 'descartado'),
        supabase
          .from('cerimonialista_modelos')
          .select('*', { count: 'exact', head: true })
          .eq('cerimonialista_id', cerimonialista.id),
      ]);

      if (!leadsRes.error) setLeadsCount(leadsRes.count || 0);
      if (!modelosRes.error) setModelosCount(modelosRes.count || 0);

      setLeadsLoading(false);
      setModelosLoading(false);
    }

    if (isCerimonialista && cerimonialista) {
      buscarDados();
    }
  }, [isCerimonialista, cerimonialista]);

  if (loading) {
    return (
      <div style={{ minHeight: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'var(--color-off-white)' }}>
        <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-muted)' }}>Carregando...</p>
      </div>
    );
  }

  if (!isCerimonialista || !cerimonialista) {
    return (
      <div style={{ minHeight: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'var(--color-off-white)', padding: 'var(--space-4)' }}>
        <div style={{ textAlign: 'center' }}>
          <Icon name="alertCircle" size={48} color="var(--color-warning)" />
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-xl)', color: 'var(--color-text-primary)', marginTop: 'var(--space-4)' }}>
            Acesso restrito
          </h2>
          <p style={{ fontFamily: 'var(--font-body)', color: 'var(--color-text-secondary)', marginTop: 'var(--space-2)' }}>
            Esta área é exclusiva para cerimonialistas.
          </p>
          <Button variant="primary" onClick={() => router.push('/painel')} style={{ marginTop: 'var(--space-6)' }}>
            Ir para o painel do casal
          </Button>
        </div>
      </div>
    );
  }

  const diasRestantes = () => {
    if (!cerimonialista.trial_inicio) return 15;
    const inicio = new Date(cerimonialista.trial_inicio);
    const hoje = new Date();
    const diff = Math.ceil((inicio.getTime() + 15 * 24 * 60 * 60 * 1000 - hoje.getTime()) / (1000 * 60 * 60 * 24));
    return Math.max(0, diff);
  };

  return (
    <>
      <Head>
        <title>Painel do Cerimonialista — Descomplicaí</title>
      </Head>

      <div style={{ minHeight: '100dvh', backgroundColor: 'var(--color-off-white)' }}>
        {/* Header */}
        <header
          style={{
            backgroundColor: 'var(--color-surface)',
            borderBottom: '1px solid var(--color-border)',
            padding: 'var(--space-4) var(--space-5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'sticky',
            top: 0,
            zIndex: 10,
          }}
        >
          <div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'var(--text-xl)',
                color: 'var(--color-text-primary)',
              }}
            >
              Bem-vindo, {cerimonialista.nome_empresa}
            </h1>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 'var(--space-1)',
                marginTop: 'var(--space-2)',
                padding: 'var(--space-1) var(--space-3)',
                borderRadius: 'var(--radius-full)',
                backgroundColor: 'var(--color-brand-light)',
                color: 'var(--color-brand)',
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--text-xs)',
                fontWeight: 'var(--font-medium)',
              }}
            >
              <Icon name="shield" size={14} />
              Trial — {diasRestantes()} dias grátis
            </div>
          </div>
          <button
            onClick={signOut}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--color-text-muted)',
              padding: 'var(--space-2)',
            }}
            aria-label="Sair"
          >
            <Icon name="logout" size={22} />
          </button>
        </header>

        {/* Conteúdo */}
        <main style={{ padding: 'var(--space-5)', maxWidth: '960px', margin: '0 auto' }}>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: 'var(--space-4)',
            }}
          >
            {/* Card Eventos Ativos */}
            <div
              style={{
                backgroundColor: 'var(--color-surface)',
                borderRadius: 'var(--radius-lg)',
                padding: 'var(--space-5)',
                border: '1px solid var(--color-border)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-3)' }}>
                <div
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: 'var(--color-brand-light)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="calendar" size={20} color="var(--color-brand)" />
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>Eventos ativos</p>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-2xl)', color: 'var(--color-text-primary)' }}>0</p>
                </div>
              </div>
              <Button variant="secondary" size="sm" fullWidth disabled>
                Novo evento
              </Button>
            </div>

            {/* Card Leads */}
            <div
              style={{
                backgroundColor: 'var(--color-surface)',
                borderRadius: 'var(--radius-lg)',
                padding: 'var(--space-5)',
                border: '1px solid var(--color-border)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-3)' }}>
                <div
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: 'var(--color-success-light)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="trendingUp" size={20} color="var(--color-success)" />
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>Leads no funil</p>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-2xl)', color: 'var(--color-text-primary)' }}>
                    {leadsLoading ? '...' : leadsCount}
                  </p>
                </div>
              </div>
              <Button variant="secondary" size="sm" fullWidth onClick={() => router.push('/cerimonialista/funil')}>
                Ver funil
              </Button>
            </div>

            {/* Card Biblioteca */}
            <div
              style={{
                backgroundColor: 'var(--color-surface)',
                borderRadius: 'var(--radius-lg)',
                padding: 'var(--space-5)',
                border: '1px solid var(--color-border)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-3)' }}>
                <div
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: 'var(--color-info-light)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="bookOpen" size={20} color="var(--color-info)" />
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>Modelos salvos</p>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-2xl)', color: 'var(--color-text-primary)' }}>
                    {modelosLoading ? '...' : modelosCount}
                  </p>
                </div>
              </div>
              <Button variant="secondary" size="sm" fullWidth onClick={() => router.push('/cerimonialista/biblioteca')}>
                Ver biblioteca
              </Button>
            </div>

            {/* Card Próximos Eventos */}
            <div
              style={{
                backgroundColor: 'var(--color-surface)',
                borderRadius: 'var(--radius-lg)',
                padding: 'var(--space-5)',
                border: '1px solid var(--color-border)',
                gridColumn: '1 / -1',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-4)' }}>
                <div
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: 'var(--color-warning-light)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="clock" size={20} color="var(--color-warning)" />
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>Próximos eventos</p>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-2xl)', color: 'var(--color-text-primary)' }}>Nenhum ainda</p>
                </div>
              </div>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>
                Seus eventos agendados aparecerão aqui.
              </p>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}
