#!/bin/bash
# Instalação da Vitrine do Cerimonialista
# Rode na raiz do projeto: bash install_vitrine.sh

set -e

echo "📦 Instalando Vitrine do Cerimonialista..."

# Criar diretórios
mkdir -p pages/vitrine
mkdir -p pages/api/vitrine
mkdir -p components/vitrine

# Copiar arquivos
cp vitrine/\[id\].jsx pages/vitrine/[id].jsx
cp vitrine/api_\[id\].js pages/api/vitrine/[id].js
cp vitrine/api_orcamento.js pages/api/vitrine/orcamento.js
cp vitrine/ContatoCard.jsx components/vitrine/ContatoCard.jsx

echo "✅ Arquivos instalados:"
echo "   pages/vitrine/[id].jsx"
echo "   pages/api/vitrine/[id].js"
echo "   pages/api/vitrine/orcamento.js"
echo "   components/vitrine/ContatoCard.jsx"

echo ""
echo "⚠️  Verifique antes de deploy:"
echo "   1. SUPABASE_SERVICE_ROLE_KEY está configurada na Vercel"
echo "   2. A variável NEXT_PUBLIC_SITE_URL está definida (ex: https://seusite.vercel.app)"
echo "   3. O cerimonialista tem ativo=true para aparecer na vitrine"
echo ""
echo "🚀 Pronto para commit/push!"
