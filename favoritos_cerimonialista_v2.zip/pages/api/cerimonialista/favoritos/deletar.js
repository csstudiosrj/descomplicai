import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export default async function handler(req, res) {
  if (req.method !== 'DELETE') {
    res.setHeader('Allow', ['DELETE']);
    return res.status(405).json({ error: `Metodo ${req.method} nao permitido` });
  }

  if (!supabaseUrl || !supabaseServiceKey) {
    return res.status(500).json({ error: 'Configuracao do Supabase incompleta' });
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token de autenticacao nao fornecido' });
  }

  const token = authHeader.replace('Bearer ', '');
  const { data: { user }, error: authError } = await supabase.auth.getUser(token);
  if (authError || !user) {
    return res.status(401).json({ error: 'Token invalido' });
  }

  const { data: cerimonialista, error: cerimError } = await supabase
    .from('cerimonialistas')
    .select('id')
    .eq('usuario_id', user.id)
    .single();

  if (cerimError || !cerimonialista) {
    return res.status(403).json({ error: 'Usuario nao e cerimonialista' });
  }

  try {
    const { id } = req.query;
    if (!id) {
      return res.status(400).json({ error: 'ID do favorito e obrigatorio' });
    }

    // Verificar se o favorito pertence ao cerimonialista
    const { data: existente } = await supabase
      .from('cerimonialista_fornecedores_favoritos')
      .select('id')
      .eq('id', id)
      .eq('cerimonialista_id', cerimonialista.id)
      .single();

    if (!existente) {
      return res.status(403).json({ error: 'Favorito nao encontrado ou nao pertence a voce' });
    }

    const { error } = await supabase
      .from('cerimonialista_fornecedores_favoritos')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return res.status(200).json({ success: true, message: 'Favorito removido' });
  } catch (err) {
    console.error('[API favoritos/deletar]', err);
    return res.status(500).json({ error: err.message || 'Erro interno' });
  }
}
