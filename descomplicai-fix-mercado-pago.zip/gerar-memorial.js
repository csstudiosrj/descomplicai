import { withRateLimit, cadastroLimiter } from '@/lib/rateLimit.js';
import { gerarMemorialLocal } from '../../../utils/gerador-templates';
import { supabase } from '../../../lib/supabase';
import { trackServerEvent } from '../../../utils/trackServerEvent';

async function _handler(req, res) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ erro: 'Não autorizado' });
  }

  const token = authHeader.replace('Bearer ', '').trim();
  const { data: { user }, error: authError } = await supabase.auth.getUser(token);
  if (authError || !user) {
    return res.status(401).json({ erro: 'Não autorizado' });
  }

  try {
    if (req.method !== 'POST') {
      return res.status(405).json({ erro: 'Método não permitido' });
    }

    const dados = req.body;

    if (!dados || Object.keys(dados).length === 0) {
      return res.status(400).json({ erro: 'Dados do memorial não fornecidos' });
    }

    console.log('[gerar-memorial] Gerando memorial para usuario:', user.id, 'dados keys:', Object.keys(dados).length);

    const memorial = gerarMemorialLocal(dados);

    if (!memorial || memorial.length < 50) {
      console.error('[gerar-memorial] Memorial vazio ou muito curto');
      return res.status(500).json({ erro: 'Erro ao gerar memorial — conteúdo vazio' });
    }

    console.log('[gerar-memorial] Memorial gerado com sucesso. Tamanho:', memorial.length);

    // Track analytics
    await trackServerEvent({
      tipo: 'acao',
      categoria: 'memorial',
      acao: 'gerado_ia',
      usuario_id: user.id,
      req,
    });

    return res.status(200).json({ sucesso: true, memorial });
  } catch (error) {
    console.error('Erro em ia/gerar-memorial:', error.message, error.stack);
    return res.status(500).json({
      erro: 'Erro interno do servidor. Tente novamente.',
      detalhe: process.env.NODE_ENV === 'development' ? error.message : undefined,
    });
  }
}

// Rate limit: cadastroLimiter
export default withRateLimit(_handler, cadastroLimiter);
