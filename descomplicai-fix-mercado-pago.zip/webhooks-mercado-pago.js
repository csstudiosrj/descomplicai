import { createClient } from '@supabase/supabase-js';
import { MercadoPagoConfig, Payment } from 'mercadopago';
import { enviarEmailTemplate } from '@/lib/email';
import { validarWebhookSeguro } from '@/lib/mercadopago';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// FIX: padroniza para MP_ACCESS_TOKEN
const client = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
});

/**
 * POST /api/webhooks/mercado-pago
 * Recebe notificações do Mercado Pago (IPN / Webhook)
 * 
 * FIX: agora delega pagamentos de casal para o webhook unificado
 * e só processa pagamentos de fornecedor
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Metodo nao permitido' });
  }

  // ─── VALIDAÇÃO DE ASSINATURA DO WEBHOOK ───
  const podeContinuar = validarWebhookSeguro(req, res)
  if (!podeContinuar) return

  // Mercado Pago envia query params: type, data.id
  const { type, 'data.id': dataId } = req.query;
  const { action, data: bodyData } = req.body;

  // Aceita tanto query params (IPN) quanto body (webhook)
  const paymentId = dataId || bodyData?.id;
  const eventType = type || action;

  if (!paymentId) {
    return res.status(400).json({ error: 'ID do pagamento nao encontrado' });
  }

  // Confirma pagamento na API do Mercado Pago
  try {
    const payment = new Payment(client);
    const paymentData = await payment.get({ id: paymentId });

    const status = paymentData.status; // approved, pending, rejected, etc.
    const externalRef = paymentData.external_reference;
    const metadata = paymentData.metadata || {};

    // FIX: detecta se é pagamento de casal (novo formato ou JSON antigo)
    if (externalRef && (
      externalRef.startsWith('descomplicai_') || 
      (externalRef.startsWith('{') && externalRef.includes('usuarioId'))
    )) {
      console.log('[WEBHOOK FORNECEDOR] Pagamento de casal detectado. Delegando para /api/pagamento/webhook.', externalRef)
      return res.status(200).json({ 
        success: true, 
        message: 'Pagamento de casal delegado para webhook principal',
        external_reference: externalRef 
      });
    }

    // Extrai fornecedor_id do external_reference
    const fornecedorId = metadata.fornecedor_id || 
      (externalRef ? externalRef.match(/fornecedor_(.+?)_/)?.[1] : null);

    if (!fornecedorId) {
      console.log('[WEBHOOK FORNECEDOR] fornecedor_id nao encontrado. Ignorando.', { externalRef, metadata })
      // FIX: retorna 200 para o MP nao reenviar
      return res.status(200).end();
    }

    // Atualiza pagamento no banco
    await supabaseAdmin
      .from('pagamentos')
      .update({
        status: status === 'approved' ? 'pago' : status === 'pending' ? 'pendente' : 'falhou',
        mp_payment_id: String(paymentId),
        atualizado_em: new Date().toISOString(),
      })
      .eq('mp_preference_id', paymentData.preference_id)
      .or(`external_reference.eq.${externalRef}`);

    // Se pagamento aprovado, atualiza fornecedor
    if (status === 'approved') {
      const { data: fornecedor } = await supabaseAdmin
        .from('fornecedores')
        .select('id, email, nome_fantasia, status')
        .eq('id', fornecedorId)
        .single();

      if (fornecedor && fornecedor.status !== 'aprovado') {
        // Atualiza status para ativo (aguarda aprovação do admin para 'aprovado')
        await supabaseAdmin
          .from('fornecedores')
          .update({
            pagamento_status: 'pago',
            status: 'ativo', // pago, mas ainda precisa de aprovação do admin
            updated_at: new Date().toISOString(),
          })
          .eq('id', fornecedorId);

        // Envia e-mail confirmando pagamento
        await enviarEmailTemplate(
          {
            para: fornecedor.email,
            template: 'pagamento_confirmado',
            variaveis: {
              nome_fantasia: fornecedor.nome_fantasia,
              link_painel: `${process.env.NEXT_PUBLIC_SITE_URL}/fornecedor/painel`,
            },
          },
          supabaseAdmin
        );
      }
    }

    return res.status(200).json({ success: true, status, fornecedor_id: fornecedorId });
  } catch (err) {
    console.error('[WEBHOOK] Erro:', err);
    // FIX: sempre retorna 200 para o MP nao reenviar
    return res.status(200).json({ error: 'Erro ao processar webhook', detalhe: err.message });
  }
}
