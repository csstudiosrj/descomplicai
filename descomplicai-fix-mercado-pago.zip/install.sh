#!/bin/bash
# =============================================================================
# Script de instalação das correções do Descomplicai
# =============================================================================
# Uso: bash install.sh
# 
# Este script copia os arquivos corrigidos para os locais corretos do projeto.
# Execute na RAIZ do projeto (~/descomplicai).
#
# BACKUP: O script faz backup dos arquivos originais em .backup/fix-mercado-pago/
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"
BACKUP_DIR="$PROJECT_DIR/.backup/fix-mercado-pago"

echo "=========================================="
echo "  INSTALADOR DE CORREÇÕES DESCOMPLICAI"
echo "=========================================="
echo ""
echo "Diretório do projeto: $PROJECT_DIR"
echo "Diretório do script:  $SCRIPT_DIR"
echo ""

# Verifica se está na raiz do projeto
if [ ! -d "$PROJECT_DIR/pages" ] || [ ! -d "$PROJECT_DIR/lib" ]; then
    echo "❌ ERRO: Você não está na raiz do projeto Descomplicai."
    echo "   Navegue para ~/descomplicai e execute:"
    echo "   bash /caminho/para/install.sh"
    exit 1
fi

# Cria diretório de backup
mkdir -p "$BACKUP_DIR"
echo "📁 Backups serão salvos em: $BACKUP_DIR"
echo ""

# Função para fazer backup e copiar
backup_e_copiar() {
    local origem="$1"
    local destino="$2"
    local nome_arquivo=$(basename "$destino")

    if [ -f "$destino" ]; then
        cp "$destino" "$BACKUP_DIR/${nome_arquivo}.bak"
        echo "  💾 Backup: $BACKUP_DIR/${nome_arquivo}.bak"
    fi

    cp "$origem" "$destino"
    echo "  ✅ Copiado: $destino"
}

echo "📋 Arquivos que serão modificados:"
echo ""

# 1. pages/api/pagamento/criar.js
echo "1. pages/api/pagamento/criar.js"
backup_e_copiar "$SCRIPT_DIR/criar.js" "$PROJECT_DIR/pages/api/pagamento/criar.js"
echo ""

# 2. pages/api/pagamento/webhook.js
echo "2. pages/api/pagamento/webhook.js"
backup_e_copiar "$SCRIPT_DIR/webhook.js" "$PROJECT_DIR/pages/api/pagamento/webhook.js"
echo ""

# 3. pages/api/webhooks/mercado-pago.js
echo "3. pages/api/webhooks/mercado-pago.js"
backup_e_copiar "$SCRIPT_DIR/webhooks-mercado-pago.js" "$PROJECT_DIR/pages/api/webhooks/mercado-pago.js"
echo ""

# 4. lib/mercadopago.js
echo "4. lib/mercadopago.js"
backup_e_copiar "$SCRIPT_DIR/lib-mercadopago.js" "$PROJECT_DIR/lib/mercadopago.js"
echo ""

# 5. pages/memorial/conclusao.jsx
echo "5. pages/memorial/conclusao.jsx"
backup_e_copiar "$SCRIPT_DIR/conclusao.jsx" "$PROJECT_DIR/pages/memorial/conclusao.jsx"
echo ""

# 6. pages/api/ia/gerar-memorial.js
echo "6. pages/api/ia/gerar-memorial.js"
backup_e_copiar "$SCRIPT_DIR/gerar-memorial.js" "$PROJECT_DIR/pages/api/ia/gerar-memorial.js"
echo ""

echo "=========================================="
echo "  ✅ INSTALAÇÃO CONCLUÍDA!"
echo "=========================================="
echo ""
echo "📋 Resumo das correções aplicadas:"
echo ""
echo "  1. 🔑 Padronização do token MP_ACCESS_TOKEN em todos os arquivos"
echo "  2. 📧 Email fallback válido (teste@email.com) no pagamento"
echo "  3. 🔖 external_reference simplificado (não mais JSON)"
echo "  4. 🔔 Webhook unificado para casal e fornecedor"
echo "  5. 🛡️ Webhooks retornam 200 para evitar reenvio do MP"
echo "  6. ⏱️ Timeout de 15s no fetch do memorial (Edge não trava)"
echo "  7. 🔄 Flag anti-loop no useEffect de geração do memorial"
echo "  8. 📝 Logs de debug no console para rastrear erros"
echo ""
echo "⚠️  PRÓXIMOS PASSOS:"
echo ""
echo "  1. Verifique se a variável MP_ACCESS_TOKEN está na Vercel"
echo "     (remova MERCADO_PAGO_ACCESS_TOKEN se existir)"
echo ""
echo "  2. Execute: npm run build"
echo "     (ou vercel --prod se deployar direto)"
echo ""
echo "  3. Teste o pagamento novamente"
echo ""
echo "  4. Se der erro, verifique os logs na Vercel:"
echo "     vercel logs --json | grep -i 'pagamento\|webhook\|memorial'"
echo ""
echo "📁 Backups salvos em: $BACKUP_DIR"
echo "   Para reverter: cp $BACKUP_DIR/*.bak <destino>"
echo ""
