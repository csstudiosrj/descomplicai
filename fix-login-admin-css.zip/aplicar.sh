#!/bin/bash
# ============================================================
# Aplicação das correções de CSS — Login, Cadastro e Admin
# Descomplicaí — 02/07/2026
# ============================================================

set -e

ZIP_FILE="fix-login-admin-css.zip"
PROJECT_ROOT="${1:-.}"

echo "=========================================="
echo "  Aplicando correções de CSS"
echo "  Projeto: Descomplicaí"
echo "  Data: 02/07/2026"
echo "=========================================="
echo ""

# Verifica se o zip existe
if [ ! -f "$ZIP_FILE" ]; then
    echo "ERRO: Arquivo $ZIP_FILE não encontrado."
    echo "Certifique-se de executar este script no mesmo diretório do zip."
    exit 1
fi

# Verifica se está na raiz do projeto (procura por pages/ e components/)
if [ ! -d "$PROJECT_ROOT/pages" ] || [ ! -d "$PROJECT_ROOT/components" ]; then
    echo "AVISO: Diretórios 'pages/' e 'components/' não encontrados em: $PROJECT_ROOT"
    echo "Este script deve ser executado na RAIZ do projeto Next.js."
    echo ""
    read -p "Deseja continuar mesmo assim? (s/N): " confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        echo "Operação cancelada."
        exit 0
    fi
fi

# Faz backup dos arquivos originais
echo "[1/4] Criando backups..."
mkdir -p "$PROJECT_ROOT/.backups/20260702_css_fix"
cp "$PROJECT_ROOT/pages/login.jsx" "$PROJECT_ROOT/.backups/20260702_css_fix/login.jsx.bak" 2>/dev/null || true
cp "$PROJECT_ROOT/pages/cadastro.jsx" "$PROJECT_ROOT/.backups/20260702_css_fix/cadastro.jsx.bak" 2>/dev/null || true
cp "$PROJECT_ROOT/pages/admin/index.jsx" "$PROJECT_ROOT/.backups/20260702_css_fix/admin-index.jsx.bak" 2>/dev/null || true
echo "      Backups salvos em .backups/20260702_css_fix/"

# Descompacta o zip em diretório temporário
echo "[2/4] Descompactando arquivos..."
TMP_DIR=$(mktemp -d)
unzip -q "$ZIP_FILE" -d "$TMP_DIR"

# Aplica os arquivos corrigidos
echo "[3/4] Aplicando correções..."
cp "$TMP_DIR/pages/login.jsx" "$PROJECT_ROOT/pages/login.jsx"
echo "      ✓ pages/login.jsx"
cp "$TMP_DIR/pages/cadastro.jsx" "$PROJECT_ROOT/pages/cadastro.jsx"
echo "      ✓ pages/cadastro.jsx"
cp "$TMP_DIR/pages/admin/index.jsx" "$PROJECT_ROOT/pages/admin/index.jsx"
echo "      ✓ pages/admin/index.jsx"

# Limpa diretório temporário
rm -rf "$TMP_DIR"

# Verifica se o globals.css tem a animação spin (necessária para o loading do admin)
echo "[4/4] Verificando dependências CSS..."
if ! grep -q "@keyframes spin" "$PROJECT_ROOT/styles/globals.css" 2>/dev/null; then
    echo "      Adicionando @keyframes spin ao globals.css..."
    cat >> "$PROJECT_ROOT/styles/globals.css" << 'EOF'

/* ============================================================
   Animação spin (usada em loading states)
   ============================================================ */
@keyframes spin {
  to { transform: rotate(360deg); }
}
EOF
    echo "      ✓ @keyframes spin adicionado"
else
    echo "      ✓ @keyframes spin já existe"
fi

echo ""
echo "=========================================="
echo "  ✅ Correções aplicadas com sucesso!"
echo "=========================================="
echo ""
echo "Arquivos modificados:"
echo "  • pages/login.jsx       (Tailwind → CSS puro)"
echo "  • pages/cadastro.jsx    (Tailwind → CSS puro)"
echo "  • pages/admin/index.jsx (Tailwind → CSS puro)"
echo ""
echo "Próximos passos:"
echo "  1. Execute: npm run dev"
echo "  2. Teste as URLs:"
echo "     - /login"
echo "     - /cadastro"
echo "     - /admin"
echo ""
echo "Se precisar reverter:"
echo "  cp .backups/20260702_css_fix/*.bak pages/ (e pages/admin/)"
echo ""
