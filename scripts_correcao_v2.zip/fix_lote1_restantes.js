/**
 * Script DEFINITIVO para corrigir hardcode nos 9 arquivos restantes do LOTE 1
 * USO: node fix_lote1_restantes.js
 */

const fs = require('fs');
const path = require('path');

const STEPS_DIR = './components/memorial/steps';

const arquivos = [
  'StepE1EstadoCivilNoivo.jsx',
  'StepE7NacionalidadeNoivo.jsx',
  'StepD11TrajeNoivoContratado.jsx',
  'StepB9CursoNoivos.jsx',
  'StepL4CarroNoivos.jsx',
  'StepE6CertidaoObitoNoiva.jsx',
  'StepE5CertidaoObitoNoivo.jsx',
  'StepE14HorarioMakingOfNoivo.jsx',
  'Step00Casal.jsx',
];

function processFile(filename) {
  const filePath = path.join(STEPS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    console.log(`⚠️  ${filename} — arquivo não encontrado`);
    return;
  }

  let content = fs.readFileSync(filePath, 'utf-8');
  const original = content;
  let changed = false;

  // Verificar se já tem import e const
  const hasImport = content.includes("import { getTermos } from '../../../utils/linguagemCasal'");
  const hasConst = content.includes('const perfil = estadoAtual?.perfilCasal') && 
                   content.includes('const termos = getTermos(perfil)');

  if (!hasImport || !hasConst) {
    console.log(`⚠️  ${filename} — não tem import/const padrão, pulando`);
    return;
  }

  console.log(`\n▶ ${filename}`);

  // ============================================
  // SUBSTITUIÇÕES POR ARQUIVO
  // ============================================

  if (filename === 'StepE1EstadoCivilNoivo.jsx') {
    // Comentário topo
    content = content.replace(/Qual o estado civil do noivo\?/, 'Estado civil');
    // aria-label
    content = content.replace(/aria-label="Estado civil do noivo"/, 'aria-label={`Estado civil do ${termos.pessoa2}`}');
    // Título
    content = content.replace(/Qual o estado civil do noivo\?/, '{`Qual o estado civil do ${termos.pessoa2}?`}');
    // Descrições das opções
    content = content.replace(/Nunca casou no civil/, '{`Nunca teve ${termos.celebracao} civil`}');
    content = content.replace(/Já teve evento civil anterior/, '{`Já teve ${termos.celebracao} civil anterior`}');
    // Labels neutros
    content = content.replace(/label: "Solteiro"/, 'label: `Solteiro(a)`');
    content = content.replace(/label: "Divorciado"/, 'label: `Divorciado(a)`');
    content = content.replace(/label: "Viúvo"/, 'label: `Viúvo(a)`');
    changed = true;
  }

  if (filename === 'StepE7NacionalidadeNoivo.jsx') {
    content = content.replace(/Qual a nacionalidade do noivo\?/, '{`Qual a nacionalidade do ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Nacionalidade do noivo"/, 'aria-label={`Nacionalidade do ${termos.pessoa2}`}');
    content = content.replace(/label: "Brasileiro"/, 'label: `Brasileiro(a)`');
    content = content.replace(/label: "Outro"/, 'label: `Outro(a)`');
    changed = true;
  }

  if (filename === 'StepD11TrajeNoivoContratado.jsx') {
    content = content.replace(/Traje do noivo/, '{`Traje do ${termos.pessoa2}`}');
    content = content.replace(/Qual o traje do noivo\?/, '{`Qual o traje do ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Traje do noivo"/, 'aria-label={`Traje do ${termos.pessoa2}`}');
    changed = true;
  }

  if (filename === 'StepB9CursoNoivos.jsx') {
    content = content.replace(/Curso dos noivos/, '{`Curso dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/Qual o curso dos noivos\?/, '{`Qual o curso dos ${termos.pessoa1} e ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Curso dos noivos"/, 'aria-label={`Curso dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    changed = true;
  }

  if (filename === 'StepL4CarroNoivos.jsx') {
    content = content.replace(/Carro dos noivos/, '{`Carro dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/Qual o carro dos noivos\?/, '{`Qual o carro dos ${termos.pessoa1} e ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Carro dos noivos"/, 'aria-label={`Carro dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    changed = true;
  }

  if (filename === 'StepE6CertidaoObitoNoiva.jsx') {
    content = content.replace(/Certidão de óbito da noiva/, '{`Certidão de óbito do(a) ${termos.pessoa1}`}');
    content = content.replace(/Certidão de óbito do cônjuge/, '{`Certidão de óbito do(a) ${termos.pessoa1}`}');
    content = content.replace(/Qual a certidão de óbito da noiva\?/, '{`Qual a certidão de óbito do(a) ${termos.pessoa1}?`}');
    content = content.replace(/Qual a certidão de óbito do cônjuge\?/, '{`Qual a certidão de óbito do(a) ${termos.pessoa1}?`}');
    content = content.replace(/aria-label="Certidão de óbito da noiva"/, 'aria-label={`Certidão de óbito do(a) ${termos.pessoa1}`}');
    content = content.replace(/aria-label="Certidão de óbito do cônjuge"/, 'aria-label={`Certidão de óbito do(a) ${termos.pessoa1}`}');
    changed = true;
  }

  if (filename === 'StepE5CertidaoObitoNoivo.jsx') {
    content = content.replace(/Certidão de óbito do noivo/, '{`Certidão de óbito do(a) ${termos.pessoa2}`}');
    content = content.replace(/Certidão de óbito do cônjuge/, '{`Certidão de óbito do(a) ${termos.pessoa2}`}');
    content = content.replace(/Qual a certidão de óbito do noivo\?/, '{`Qual a certidão de óbito do(a) ${termos.pessoa2}?`}');
    content = content.replace(/Qual a certidão de óbito do cônjuge\?/, '{`Qual a certidão de óbito do(a) ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Certidão de óbito do noivo"/, 'aria-label={`Certidão de óbito do(a) ${termos.pessoa2}`}');
    content = content.replace(/aria-label="Certidão de óbito do cônjuge"/, 'aria-label={`Certidão de óbito do(a) ${termos.pessoa2}`}');
    changed = true;
  }

  if (filename === 'StepE14HorarioMakingOfNoivo.jsx') {
    content = content.replace(/Horário do making of do noivo/, '{`Horário do making of do ${termos.pessoa2}`}');
    content = content.replace(/Making of do noivo/, '{`Making of do ${termos.pessoa2}`}');
    content = content.replace(/Qual o horário do making of do noivo\?/, '{`Qual o horário do making of do ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Horário do making of do noivo"/, 'aria-label={`Horário do making of do ${termos.pessoa2}`}');
    content = content.replace(/aria-label="Making of do noivo"/, 'aria-label={`Making of do ${termos.pessoa2}`}');
    changed = true;
  }

  if (filename === 'Step00Casal.jsx') {
    content = content.replace(/Dados do casal/, '{`Dados dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/Informações do casal/, '{`Informações dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/Sobre o casal/, '{`Sobre os ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/Qual o nome do casal\?/, '{`Qual o nome dos ${termos.pessoa1} e ${termos.pessoa2}?`}');
    content = content.replace(/aria-label="Dados do casal"/, 'aria-label={`Dados dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    content = content.replace(/aria-label="Informações do casal"/, 'aria-label={`Informações dos ${termos.pessoa1} e ${termos.pessoa2}`}');
    // "casamento" em texto
    content = content.replace(/"casamento"/, '{`${termos.celebracao}`}');
    changed = true;
  }

  if (!changed) {
    console.log(`  ℹ️  Nenhuma substituição aplicada`);
    return;
  }

  // Limpar linhas em branco duplicadas
  content = content.replace(/\n{3,}/g, '\n\n');

  // Diff resumido
  const origLines = original.split('\n');
  const modLines = content.split('\n');
  let diffCount = 0;
  for (let i = 0; i < Math.max(origLines.length, modLines.length); i++) {
    if ((origLines[i] || '') !== (modLines[i] || '')) {
      diffCount++;
    }
  }

  fs.writeFileSync(filePath, content, 'utf-8');
  console.log(`  ✅ Salvo — ${diffCount} linha(s) alterada(s)`);
}

console.log('═══════════════════════════════════════════════════════');
console.log('  CORREÇÃO LOTE 1 — 9 ARQUIVOS RESTANTES');
console.log('═══════════════════════════════════════════════════════\n');

for (const arquivo of arquivos) {
  processFile(arquivo);
}

console.log('\n═══════════════════════════════════════════════════════');
console.log('  CONCLUÍDO');
console.log('═══════════════════════════════════════════════════════');
console.log('\nPróximo passo: npm run build');
